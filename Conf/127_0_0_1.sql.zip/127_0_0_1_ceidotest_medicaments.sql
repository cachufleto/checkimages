-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 13 Juillet 2016 à 16:45
-- Version du serveur :  5.7.9
-- Version de PHP :  5.6.16

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ceidotest_medicaments`
--
DROP DATABASE `ceidotest_medicaments`;
CREATE DATABASE IF NOT EXISTS `ceidotest_medicaments` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ceidotest_medicaments`;

-- --------------------------------------------------------

--
-- Structure de la table `familles`
--

CREATE TABLE `familles` (
  `id_famille` int(11) NOT NULL,
  `designation` char(60) DEFAULT NULL,
  `ordre_affichage` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `familles`
--

INSERT INTO `familles` (`id_famille`, `designation`, `ordre_affichage`) VALUES
(0, '---', 1),
(1, 'Hygiène, Intimité', 1),
(2, 'Soins dentaires', 1),
(3, 'Circulation veineuse', 1),
(4, 'Digestion', 1),
(5, 'Douleurs et Fièvre', 1),
(6, 'Vitalité', 1),
(8, 'Yeux et Oreilles', 1),
(10, 'Peau et Cheveux', 1),
(11, 'Rhume, Gorge et Toux', 1);

-- --------------------------------------------------------

--
-- Structure de la table `laboratoires`
--

CREATE TABLE `laboratoires` (
  `id_laboratoire` int(11) NOT NULL,
  `designation` char(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `laboratoires`
--

INSERT INTO `laboratoires` (`id_laboratoire`, `designation`) VALUES
(1, 'SANOFI AVENTIS FRANCE'),
(2, 'BRISTOL MYERS SQUIBB / UPSA'),
(3, 'BOIRON DOLISOS'),
(4, 'TEVA SANTE'),
(5, 'MAYOLY SPINDLER'),
(6, 'PIERRE FABRE MEDICAMENT'),
(7, 'EXPANSCIENCE'),
(8, 'THERABEL LUCIEN PHARMA'),
(9, 'MYLAN'),
(10, 'BIOGARAN'),
(11, 'RECKITT BENCKISER HEALTHCARE'),
(12, 'UCB PHARMA SA'),
(13, 'BOEHRINGER INGELHEIM FRANCE'),
(14, 'NORGINE FRANCE'),
(15, 'MEDAPHARMA'),
(16, 'IPSEN PHARMA'),
(17, 'BAYER SANTE FAMILIALE'),
(18, 'CENTRAL CHIMIOTHERAPIE DERMOC.'),
(19, 'SUNSTAR PHARMADENT'),
(20, 'JOHNSON JOHNSON SANTE BEAUTE'),
(21, 'JOLLY JATEL'),
(22, 'GENEVRIER SA'),
(23, 'PFIZER'),
(24, 'URGO'),
(25, 'BOUCHARA RECORDATI'),
(26, 'ELERTE'),
(27, 'ARROW GENERIQUES'),
(28, 'PIERRE FABRE DERMATOLOGIE'),
(29, 'PIERRE FABRE SANTE'),
(30, 'SERVIER'),
(31, 'SANDOZ SAS'),
(32, 'TECHNI PHARMA'),
(33, 'IPRAD - ALFA WASSERMANN PHARMA'),
(34, 'ZAMBON FRANCE'),
(35, 'MENARINI FRANCE'),
(36, 'CRINEX SA'),
(37, 'BIOCODEX'),
(38, 'GRIMBERG'),
(39, 'TONIPHARM'),
(40, 'ROTTAPHARM - MADAUS'),
(41, 'COOPER'),
(42, 'GIFRER BARBEZAT'),
(43, 'EREMPHARMA'),
(44, 'EG LABO'),
(45, 'LEO PHARMA'),
(46, 'STIEFEL'),
(47, 'MERCK MEDICATION FAMILIALE SAS'),
(48, 'ABBOTT'),
(49, 'NOVARTIS SANTE FAMILIALE SAS'),
(50, 'PROCTER GAMBLE PHARMACEUTICALS'),
(51, 'ALMIRALL SAS'),
(52, 'CHAUVIN BAUSCH LOMB'),
(53, 'EUROPHTA'),
(54, 'WARNER CHILCOTT'),
(55, 'ALLERGAN FRANCE'),
(56, 'LABCATAL'),
(57, 'EFFIK'),
(58, 'THEA'),
(59, 'LEHNING'),
(60, 'FERRIER'),
(61, 'DUCRAY'),
(62, 'CRISTERS'),
(63, 'SOCIETE ETUDES RECH. BIO. SERB'),
(64, 'ALCON SA'),
(65, 'NEGMA - LERADS'),
(66, 'ALMUS FRANCE'),
(67, 'ZYDUS FRANCE SAS'),
(68, 'PLUS PHARMACIE SA'),
(69, 'APTALIS PHARMA SAS'),
(70, 'GRUNENTHAL'),
(71, 'SIGMA-TAU FRANCE'),
(72, 'HRA-PHARMA'),
(73, 'RPG RANBAXY PHARMACIE GENERIQ.'),
(74, 'CEPHALON FRANCE'),
(75, 'BROTHIER NOGUES'),
(76, 'OMEGA PHARMA'),
(77, 'TEOFARMA'),
(78, 'INNOTECH INTERNATIONAL'),
(79, 'GILBERT'),
(80, 'ALTER'),
(81, 'BAILLEUL BIORGA'),
(82, 'SINCLAIR PHARMA'),
(83, 'GLAXOSMITHKLINE SANTE GRD PUB.'),
(84, 'AMDIPHARM'),
(85, 'GALDERMA'),
(86, 'ARKOPHARMA'),
(87, 'BAYER SANTE'),
(88, 'LAPHI PPDH'),
(89, 'LABORATOIRE DES GRANIONS'),
(90, 'ASTELLAS PHARMA'),
(91, 'MSD FRANCE'),
(92, 'TRADIPHAR'),
(93, 'GERDA'),
(94, 'BESINS INTERNATIONAL'),
(95, 'DISSOLVUROL'),
(96, 'JANSSEN CILAG SA'),
(97, 'MOLNLYCKE HEALTH CARE'),
(98, 'NATURACTIVE PLANTES MEDECINES'),
(99, 'HEPATOUM'),
(100, 'CHIESI SA'),
(101, 'FERRING SA'),
(102, 'GUERBET'),
(103, 'BAILLY-CREAT'),
(104, 'DOLIAGE'),
(105, 'IPRAD'),
(106, 'PHARMASTRA'),
(107, 'HORUS PHARMA'),
(108, 'SERP'),
(109, 'DERMOPHIL INDIEN'),
(110, 'DB PHARMA'),
(111, 'SUPER DIET'),
(112, 'AEROCID'),
(113, 'GOMENOL'),
(114, 'HOMME DE FER'),
(115, 'SOFIBEL FUMOUZE'),
(116, 'B BRAUN MEDICAL SAS'),
(117, 'FUCA'),
(118, 'TOULADE'),
(119, 'M. RICHARD SAS'),
(120, 'MAJORELLE'),
(121, 'BIODIM'),
(122, 'WELEDA'),
(123, 'GABA'),
(124, 'PHARMA LAB'),
(125, 'PHARMA REFERENCE / PHR LAB'),
(126, 'BRIDE'),
(127, 'SOLVAY PHARMA'),
(128, 'TISANE PROVENCALE'),
(129, 'BIOPROJET PHARMA'),
(130, 'PHARMA DEVELOPPEMENT'),
(131, 'SODIA'),
(132, 'LISAPHARM'),
(133, 'MERCK SERONO'),
(134, 'PIONNEAU'),
(135, 'UNITHER INDUSTRIES'),
(136, 'DEXO SA'),
(137, 'EXPANPHARM INTERNATIONAL'),
(138, 'ACTAVIS - ARROW GENERIQUES'),
(139, 'NEPENTHES'),
(140, 'PHARMA 2000'),
(141, 'DIETETIQUE ET SANTE'),
(142, 'JUVISE PHARMACEUTICALS'),
(143, 'ROGE CAVAILLES SAS'),
(144, 'MEDIWIN LIMITED'),
(145, 'FORTE PHARMA'),
(146, 'RD PHARMA'),
(147, 'GLAXOSMITHKLINE'),
(148, 'BAYER HEALTHCARE'),
(149, 'GILBERT (GR. BATTEUR)'),
(150, 'FRESENIUS KABI FRANCE'),
(151, 'SANOFI ZENTIVA'),
(152, 'CHAIX ET DU MARAIS'),
(153, 'ROCHE'),
(154, 'DERMATERRA'),
(155, 'SANOFI PASTEUR MSD'),
(156, 'PHARMACIE CENTRALE DES ARMEES'),
(157, 'INNOTHERA'),
(158, 'QUALIMED'),
(159, 'KREUSSLER PHARMA'),
(160, 'ROSA PHYTOPHARMA');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id_produit` int(11) NOT NULL,
  `cis` char(15) DEFAULT NULL,
  `cip13` char(15) DEFAULT NULL,
  `id_famille` int(11) DEFAULT NULL,
  `id_sfamille` int(11) DEFAULT NULL,
  `id_ssfamille` int(11) DEFAULT NULL,
  `limite` int(11) DEFAULT NULL,
  `denomination` longtext NOT NULL,
  `presentation` text NOT NULL,
  `id_laboratoire` int(11) DEFAULT NULL,
  `id_tva` decimal(13,2) DEFAULT NULL,
  `prix_moyen` decimal(13,2) DEFAULT NULL,
  `ordre_top` int(11) DEFAULT NULL,
  `date_traitement` date DEFAULT NULL,
  `produit_actif` char(1) DEFAULT NULL,
  `prix_public` decimal(13,2) DEFAULT NULL,
  `ansm` char(100) DEFAULT NULL,
  `libelle_ospharm` char(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `s_familles`
--

CREATE TABLE `s_familles` (
  `id_sfamille` int(11) NOT NULL,
  `id_famille` int(11) DEFAULT NULL,
  `designation` char(100) DEFAULT NULL,
  `ordre_affichage` int(11) DEFAULT NULL,
  `categorie` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `s_familles`
--

INSERT INTO `s_familles` (`id_sfamille`, `id_famille`, `designation`, `ordre_affichage`, `categorie`) VALUES
(0, 0, '---', NULL, NULL),
(1, 1, 'Féminité', 1, 'a'),
(2, 1, 'Grossesse, Ménopause', 1, 'a'),
(3, 1, 'Hygiène, Protection', 1, 'a'),
(4, 1, 'Troubles urinaires', 1, 'a'),
(5, 2, 'Aphtes, Sécheresses', 1, 'a'),
(6, 2, 'Bains de bouche', 1, 'a'),
(7, 2, 'Dentifrice', 1, 'a'),
(8, 2, 'Douleurs dentaires', 1, 'a'),
(10, 3, 'Circulation', 1, 'a'),
(11, 3, 'Coups, Bleus, Bosses', 1, 'a'),
(12, 3, 'Hémorroïdes', 1, 'a'),
(13, 3, 'Hypotension', 1, 'a'),
(14, 4, 'Anti-inflammatoire', 1, 'a'),
(15, 4, 'Antiparasitaire', 1, 'a'),
(16, 4, 'Ballonnements', 1, 'a'),
(17, 4, 'Constipation', 1, 'a'),
(18, 4, 'Diarrhée', 1, 'a'),
(19, 4, 'Digestion difficile', 1, 'a'),
(20, 4, 'Maux d''estomac', 1, 'a'),
(21, 4, 'Nausées', 1, 'a'),
(22, 4, 'Protection flore', 1, 'a'),
(23, 5, 'Anti-inflammatoire: Ibuprofène', 1, 'a'),
(25, 5, 'Aspirine', 1, 'a'),
(26, 5, 'Autres', 1, 'a'),
(27, 5, 'Douleurs articulaires', 1, 'a'),
(28, 5, 'Douleurs musculaires', 1, 'a'),
(29, 5, 'Paracétamol', 1, 'a'),
(30, 6, 'Arrêt du tabac', 1, 'a'),
(31, 6, 'Carence', 1, 'a'),
(32, 6, 'Détente, Sommeil', 1, 'a'),
(33, 6, 'Vertiges, Migraines', 1, 'a'),
(34, 6, 'Vitamines, Toniques', 1, 'a'),
(35, 8, 'Lavages', 1, 'a'),
(36, 8, 'Soins', 1, 'a'),
(38, 10, 'Acné', 1, 'a'),
(39, 10, 'Anti-irritation', 1, 'a'),
(40, 10, 'Apaisant', 1, 'a'),
(41, 10, 'Bouton de fièvre', 1, 'a'),
(42, 10, 'Chute des cheveux', 1, 'a'),
(43, 10, 'Cicatrisant', 1, 'a'),
(44, 10, 'Coups de soleil, Brûlures', 1, 'a'),
(45, 10, 'Désinfectant', 1, 'a'),
(46, 10, 'Irritations, Parasites', 1, 'a'),
(47, 10, 'Mycose', 1, 'a'),
(48, 6, 'Poids', 1, 'a'),
(49, 10, 'Shampoing traitant', 1, 'a'),
(50, 10, 'Verrues, Cors', 1, 'a'),
(51, 11, 'Allergie', 1, 'a'),
(52, 11, 'Bronches, Nez', 1, 'a'),
(53, 11, 'Maux de gorge', 1, 'a'),
(55, 11, 'Rhume, Etats grippaux', 1, 'a'),
(56, 11, 'Toux', 1, 'a'),
(63, 2, 'Homéopathie', 1, 'a'),
(64, 11, 'Homéopathie', 1, 'a'),
(65, 1, 'Homéopathie', 1, 'a'),
(66, 3, 'Homéopathie', 1, 'a'),
(67, 4, 'Homéopathie', 1, 'a'),
(68, 5, 'Homéopathie', 1, 'a'),
(69, 6, 'Homéopathie', 1, 'a'),
(70, 8, 'Homéopathie', 1, 'a'),
(71, 10, 'Homéopathie', 1, 'a'),
(82, 11, 'Oligothérapie', 1, 'a'),
(87, 6, 'Oligothérapie', 1, 'a');

-- --------------------------------------------------------

--
-- Structure de la table `ss_famille`
--

CREATE TABLE `ss_famille` (
  `id_ssfamille` int(11) NOT NULL,
  `id_sfamille` int(11) DEFAULT NULL,
  `id_famille` int(11) DEFAULT NULL,
  `designation` char(100) DEFAULT NULL,
  `ordre_affichage` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `ss_famille`
--

INSERT INTO `ss_famille` (`id_ssfamille`, `id_sfamille`, `id_famille`, `designation`, `ordre_affichage`) VALUES
(0, 0, 0, '---', NULL),
(1, 29, 5, 'Dafalgan', 1),
(2, 29, 5, 'Doliprane', 1),
(3, 29, 5, 'Efferalgan', 1),
(13, 65, 1, 'Troubles urinaires', 1),
(14, 66, 3, 'Circulation', 1),
(15, 68, 5, 'Coups, Bleus, Bosses', 1),
(16, 66, 3, 'Hémorroïdes', 1),
(17, 67, 4, 'Diarrhée', 1),
(18, 67, 4, 'Digestion difficile', 1),
(19, 70, 8, 'Lavages', 1),
(20, 71, 10, 'Cicatrisant', 1),
(22, 71, 10, 'Verrues, Cors', 1),
(23, 69, 6, 'Mal des transports', 1),
(24, 68, 5, 'Douleurs articulaires', 1),
(26, 63, 2, 'Douleurs dentaires', 1),
(27, 69, 6, 'Détente, Sommeil', 1),
(28, 69, 6, 'Vertiges, Migraines', 1),
(29, 69, 6, 'Vitamines', 1),
(30, 71, 10, 'Allergie', 1),
(31, 64, 11, 'Maux de gorge, Allergie', 1),
(32, 64, 11, 'Rhume, Etats grippaux', 1),
(34, 64, 11, 'Toux, Bronches', 1),
(49, 87, 6, 'Détente, Sommeil', 1),
(52, 66, 3, 'Coups, Bleus, Bosses', 1),
(55, 29, 5, 'Autres', 1),
(56, 68, 5, 'Fièvre, Grippe et Rhume', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `familles`
--
ALTER TABLE `familles`
  ADD PRIMARY KEY (`id_famille`);

--
-- Index pour la table `laboratoires`
--
ALTER TABLE `laboratoires`
  ADD PRIMARY KEY (`id_laboratoire`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id_produit`);

--
-- Index pour la table `s_familles`
--
ALTER TABLE `s_familles`
  ADD PRIMARY KEY (`id_sfamille`);

--
-- Index pour la table `ss_famille`
--
ALTER TABLE `ss_famille`
  ADD PRIMARY KEY (`id_ssfamille`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `familles`
--
ALTER TABLE `familles`
  MODIFY `id_famille` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `laboratoires`
--
ALTER TABLE `laboratoires`
  MODIFY `id_laboratoire` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id_produit` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `s_familles`
--
ALTER TABLE `s_familles`
  MODIFY `id_sfamille` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ss_famille`
--
ALTER TABLE `ss_famille`
  MODIFY `id_ssfamille` int(11) NOT NULL AUTO_INCREMENT;