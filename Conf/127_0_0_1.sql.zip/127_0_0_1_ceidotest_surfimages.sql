--
-- Base de données :  `ceidotest_surfimages`
--
DROP DATABASE `ceidotest_surfimages`;
CREATE DATABASE IF NOT EXISTS `ceidotest_surfimages` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ceidotest_surfimages`;

-- --------------------------------------------------------

--
-- Structure de la table `control_images`
--

CREATE TABLE `control_images` (
  `cip13` varchar(13) NOT NULL,
  `image` tinyint(1) NOT NULL,
  `vignette` tinyint(1) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `site` varchar(255) DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `produit` varchar(255) DEFAULT NULL,
  `upload` tinyint(1) DEFAULT '0',
  `zapper` tinyint(4) DEFAULT '0',
  `cip13` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Liste des images';

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id_image` int(10) UNSIGNED NOT NULL,
  `id` int(10) UNSIGNED NOT NULL,
  `cip13` char(15) DEFAULT NULL,
  `denomination` longtext NOT NULL,
  `presentation` text NOT NULL,
  `type` int(1) DEFAULT NULL,
  `date_traitement` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `libelle` char(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `produitsmodifications`
--

CREATE TABLE `produitsmodifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `cip13` varchar(13) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `etat` tinyint(1) NOT NULL DEFAULT '0',
  `message` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `control_images`
--
ALTER TABLE `control_images`
  ADD UNIQUE KEY `cip13` (`cip13`);

--
-- Index pour la table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nom` (`nom`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produitsmodifications`
--
ALTER TABLE `produitsmodifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `CIP13` (`cip13`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `produitsmodifications`
--
ALTER TABLE `produitsmodifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;